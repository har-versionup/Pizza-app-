Video Explanation on [EduRise Channel](http://bit.ly/edurise_js)

[Pizza Builder in 1 hour](https://bit.ly/pizzajs)

To run the project, simply run the following commands

1. `npm install` or `yarn install`
2. `npm start` or `yarn start`

[Images and Assets Here](https://github.com/dhavaljardosh/PizzaBuilder/tree/master/src/assets)
